<template>
  <div>
    <!-- <site-header /> -->
    <nuxt />
  </div>
</template>

<script>

import site_header from '@/components/website/member-header.vue'
export default {
  components: {
    "site-header": site_header
  }
}
</script>

<style>
</style>
