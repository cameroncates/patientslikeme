<template>
<div>
    <button @click="$router.push('/')"  class="btn btn-hov btn-lg ls-2">
        <h1 class="font-weight-normal text-primary">CFBPSN</h1> 
    </button>
</div>
</template>

<script>
export default {

}
</script>

<style>
</style>